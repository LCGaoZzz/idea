#!/usr/bin/env python3
"""Synthetic counterexamples for static code semantics, NOT paper reproduction.

Uses only Python's standard library. Does not read patient data, run author R
code, estimate biological effects, or reproduce any published figure.
Run: python code_audit/semantic_examples.py --output code_audit/semantic_checks.json
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
from typing import Any


def display_positive(smoothed_axl: float, nearest_any_tam: float) -> bool:
    """Logical predicate transcribed in fresh Python from the audited R formula."""
    if not all(math.isfinite(x) and x >= 0 for x in (smoothed_axl, nearest_any_tam)):
        raise ValueError("Toy inputs must be finite and non-negative")
    return smoothed_axl > 0.1 and nearest_any_tam < 50


def run_examples() -> list[dict[str, Any]]:
    tests: list[dict[str, Any]] = []
    def add(name: str, observed: Any, expected: Any, note: str) -> None:
        passed = math.isclose(observed, expected, rel_tol=1e-12, abs_tol=1e-12) if isinstance(observed,float) and isinstance(expected,float) else observed == expected
        tests.append(dict(name=name,observed=observed,expected=expected,passed=passed,note=note))
        if not passed:
            raise AssertionError(f"{name}: {observed!r} != {expected!r}")
    add('marker_high_remote_tumor',display_positive(0.5,60),False,
        'A marker-high tumor outside the distance gate retains the display-negative label.')
    add('marker_high_close_tumor',display_positive(0.5,10),True,
        'The display category depends on a joint marker-distance predicate.')
    add('expression_threshold_is_strict',display_positive(0.1,10),False,
        'Equality at the expression cutoff does not qualify.')
    add('distance_threshold_is_strict',display_positive(0.5,50),False,
        'Equality at the distance cutoff does not qualify.')
    # Own value is zero; one neighboring value is 2.2; 18 further zeros.
    values=[0.0,2.2]+[0.0]*18
    add('neighbor_smoothing_can_label_own_zero_positive',sum(values)/len(values)>0.1,True,
        'This uses a prescribed neighborhood, not RANN or real expression data.')
    add('any_tam_gate_not_positive_tam_gate',display_positive(0.5,min(10,80)),True,
        'Toy nearest negative TAM is 10 units away, positive TAM 80; any-TAM gate passes.')
    add('residence_not_enrichment',(40/50)/(80/100),1.0,
        '80% residence equals the toy parent-lineage background; enrichment is one.')
    add('poisson_density_distance_scaling',(1/(2*math.sqrt(4)))/(1/(2*math.sqrt(1))),0.5,
        'Analytic homogeneous unbounded 2D Poisson null, not a tissue-data correction.')
    coords_order=['cell_B','cell_A']; expr_order=['cell_A','cell_B']; values_by_expr=[0,2]
    positional=values_by_expr[0]
    aligned=dict(zip(expr_order,values_by_expr))[coords_order[0]]
    add('positional_alignment_counterexample',(positional,aligned),(0,2),
        'A position index can disagree with barcode lookup when arrays are permuted.')
    return tests


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    tests=run_examples()
    result={'scope':'Synthetic logical examples only; not author-code or scientific-data execution',
            'author_code_run':False,'study_data_used':False,'tests':tests,
            'passed_count':sum(t['passed'] for t in tests),'total':len(tests)}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"Synthetic semantic examples: {result['passed_count']}/{result['total']} passed. No study data used.")

if __name__ == '__main__':
    main()
