# Agent恢复入口：MDR论文代码证据包

**职责**：继续这篇特定论文的证据补齐、代码语义核对与可复查分析。不得把当前包当作已通读全文或已复现结果。

先读`../evidence/scope_boundary.json`与`../working_state.json`，再按问题读取`../knowledge/DEEP_REVIEW_ZH.md`，不要把全部审计记录无差别塞入上下文。

固定对象：Cell Reports Medicine，PII S2666-3791(26)00469-6；作者仓库KangjieShen/MDR_Code，commit f0fd6fc17654541fa97e49dbaf93cde583ee55a7。源文件哈希及固定链接在`../evidence/repository_file_manifest.json`。当前ZIP默认不包含这些源字节；使用原协议验证器重新验证时，需先按来源恢复并核对哈希，不能修改清单来“通过”。

## 状态与下一步

论文正文、Methods、原图/图注和补充材料未取得，主路径停止在证据获取。A01–A12的论文重建状态全部为受阻。当前另做了显式缩小范围的只读源代码审计和原创方法学解释，不代表正式跨材料科学审计已通过。

获得新材料后，先登记来源、版本、哈希与权限，再逐个analysis_id补齐正文主张、图、方法。优先核对S12B与S12D分组差异、S12H距离表来源、临床Cox设计和跨模态标记对应。保留已有快照，不无故重新抓取或换成main最新版本。

数据分析只能在有授权、有输入且对象契约明确后执行。不要补写QC阈值、样本数、药物或干预结果。默认assay、基因命名、坐标单位、barcode顺序、sample/FOV边界和患者层次必须明确。

## 关键不可混淆项

展示用nexus_identity与统计用stat_identity不同；前者AXL肿瘤标签含到任意TAM的距离，后者按counts>0。CN是主要细胞类型的KNN比例聚类。驻留比例为P(CN|状态)，不是富集。S12H读取的距离表生成过程缺失。Figure 7.R是逐变量单因素Cox。主分析CXCL14CAF与Xenium CXCL12CAF、TREM2与SPP1状态需要实际对应验证。

## 已执行操作

安全解包、源码指纹、只读静态库存、结构/状态验证。`code_audit/semantic_examples.py`只执行了原创Python数学反例，不运行作者R脚本，不使用论文数据，不是科学复现。自动审计的误报订正在`code_audit/manual_adjudication.json`。

输出保持四分法：论文报告、公开实现、逻辑解释、迁移建议。所有新的结果都必须有对应来源或真实执行记录；薄入口无需另建工作流引擎、恢复状态机或多余审批。
