# Reconstruction delivery

- Project: `MDR_CellReportsMedicine_20260917_source_limited`
- Derived status: `受阻`
- Analyses represented: `12`
- Qualifying successful executions: `0`
- Validation: `validation_report.json` (`valid: true`)

## Start here

1. Read `REPORT.md` for the evidence-bounded interpretation.
2. Read `traceability.tsv` to follow every claim through Methods, code, I/O, and status.
3. Read `reconstruction_manifest.json` for the authoritative structured record.
4. Read `validation_report.json` for contract scope, warnings, and limitations.
5. Read `repository_audit.json` when present for static execution-readiness findings.

## Meaning of the status

The project is blocked or partial; exact blockers remain in the manifest and report.

The validator checks structure, linkage, hashes, and bounded provenance. It does not by itself prove biological correctness or signed process-to-artifact causality.
